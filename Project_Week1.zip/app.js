// app.js
require("dotenv").config();
const path = require("path");
const express = require("express");
const exphbs = require("express-handlebars");
const mongoose = require("mongoose");

const User = require("./models/User");
const Portfolio = require("./models/Portfolio");

const app = express();
const PORT = process.env.PORT || 3000;

// Handlebars setup
const hbs = exphbs.create({
  extname: ".hbs",
  defaultLayout: "main",
  layoutsDir: path.join(__dirname, "views", "layouts"),
  partialsDir: path.join(__dirname, "views", "partials"),
  helpers: {
    formatDate(date) {
      if (!date) return "";
      return new Date(date).toLocaleString();
    },
    ifEquals(a, b, options) {
      return String(a) === String(b) ? options.fn(this) : options.inverse(this);
    },
  },
});

app.engine(".hbs", hbs.engine);
app.set("view engine", ".hbs");
app.set("views", path.join(__dirname, "views"));

// Serve static files
app.use("/static", express.static(path.join(__dirname, "public")));

// Connect to MongoDB
const MONGODB_URI =
  process.env.MONGODB_URI || "mongodb://localhost:27017/portfolio_db";
mongoose
  .connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Route: profile view (server renders with Handlebars)
app.get("/profile/:userId", async (req, res, next) => {
  try {
    const userId = req.params.userId;
    // fetch user and portfolios
    const user = await User.findById(userId).lean();
    if (!user) return res.status(404).send("User not found");

    const portfolios = await Portfolio.find({ ownerId: user._id })
      .sort({ updatedAt: -1 })
      .lean();

    res.render("profile", {
      user,
      portfolios,
      year: new Date().getFullYear(),
    });
  } catch (err) {
    next(err);
  }
});

app.post(
  "/portfolios/:id/delete",
  express.urlencoded({ extended: true }),
  async (req, res) => {
    try {
      const id = req.params.id;
      const p = await Portfolio.findById(id);
      if (!p) return res.status(404).send("Portfolio not found");
      await Portfolio.deleteOne({ _id: id });
      // unset active if needed
      await User.updateOne(
        { activePortfolioId: id },
        { $unset: { activePortfolioId: "" } }
      );
      res.redirect("back");
    } catch (err) {
      res.status(500).send("Delete failed");
    }
  }
);

// Root redirect (optional)
app.get("/", (req, res) => {
  res.send("Visit /profile/:userId — example: /profile/USER_ID");
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send("Server error");
});

app.listen(PORT, () =>
  console.log(`Server running at http://localhost:${PORT}`)
);
