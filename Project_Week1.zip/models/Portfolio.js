// models/Portfolio.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const PortfolioSchema = new Schema(
  {
    ownerId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    title: { type: String, default: "Untitled" },
    description: { type: String, default: "" },
    sections: { type: [Schema.Types.Mixed], default: [] },
    layout: {
      singlePage: { type: Boolean, default: true },
      pages: { type: [String], default: [] },
    },
    themeId: { type: Schema.Types.ObjectId, ref: "Theme", default: null },
    contactButtonEnabled: { type: Boolean, default: false },
    contactEmail: { type: String, default: "" },
    isExample: { type: Boolean, default: false },
    copiedFromPortfolioId: {
      type: Schema.Types.ObjectId,
      ref: "Portfolio",
      default: null,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Portfolio", PortfolioSchema);
