// models/User.js
const mongoose = require("mongoose");
const { Schema } = mongoose;

const UserSchema = new Schema(
  {
    username: { type: String, required: true, index: true },
    email: { type: String, required: true, unique: true },
    profilePictureId: {
      type: Schema.Types.ObjectId,
      ref: "File",
      default: null,
    },
    activePortfolioId: {
      type: Schema.Types.ObjectId,
      ref: "Portfolio",
      default: null,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", UserSchema);
