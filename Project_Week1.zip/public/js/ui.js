// public/js/ui.js
document.addEventListener("DOMContentLoaded", function () {
  const avatarBtn = document.getElementById("avatarBtn");
  const dropdown = document.getElementById("avatarDropdown");
  if (!avatarBtn || !dropdown) return;

  avatarBtn.addEventListener("click", (e) => {
    dropdown.classList.toggle("hidden");
  });

  // close when clicking outside
  document.addEventListener("click", (e) => {
    if (!avatarBtn.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.classList.add("hidden");
    }
  });
});
